Context
Since 2008, guests and hosts have used Airbnb to expand on traveling possibilities and present more unique, personalized way of experiencing the world. This dataset describes the listing activity and metrics in NYC, NY for 2019.

Content
This data file includes all needed information to find out more about hosts, geographical availability, necessary metrics to make predictions and draw conclusions.

Acknowledgements
This public dataset is part of Airbnb, and the original source can be found on this website.

"Columns"
idlisting ID
namename of the listing
host_idhost ID
host_namename of the host
neighbourhood_grouplocation
neighbourhoodarea
latitudelatitude coordinates
longitudelongitude coordinates
room_typelisting space type
priceprice in dollars
minimum_nightsamount of nights minimum
number_of_reviewsnumber of reviews
last_reviewlatest review
reviews_per_monthnumber of reviews per month
calculated_host_listings_countamount of listing per host
availability_365number of days when listing is available for booking